"""
FastAPI service wrapping a ResNet18 image classifier.

Endpoints:
    GET  /              - basic service info
    GET  /health        - health check (also reports whether model is loaded)
    POST /predict       - upload an image, get back predicted class + probabilities

Run locally:
    uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload

Docs (Swagger UI) once running:
    http://localhost:8000/docs
"""

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import JSONResponse

from app.model import model_wrapper
from app.schemas import HealthResponse, PredictionResponse

app = FastAPI(
    title="Image Classifier API",
    description="Serves predictions from a ResNet18 transfer-learning "
                "image classifier (see /docs for interactive testing).",
    version="1.0.0",
)

ALLOWED_CONTENT_TYPES = {"image/jpeg", "image/png", "image/jpg", "image/webp"}


@app.get("/", tags=["meta"])
def root():
    return {
        "service": "Image Classifier API",
        "docs": "/docs",
        "endpoints": ["/health", "/predict"],
    }


@app.get("/health", response_model=HealthResponse, tags=["meta"])
def health():
    return HealthResponse(
        status="ok",
        model_loaded=model_wrapper.loaded,
        device=str(model_wrapper.device),
    )


@app.post("/predict", response_model=PredictionResponse, tags=["inference"])
async def predict(file: UploadFile = File(..., description="Image file (jpg/png/webp)")):
    if file.content_type not in ALLOWED_CONTENT_TYPES:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported content type '{file.content_type}'. "
                   f"Allowed: {sorted(ALLOWED_CONTENT_TYPES)}",
        )

    image_bytes = await file.read()
    if not image_bytes:
        raise HTTPException(status_code=400, detail="Uploaded file is empty.")

    try:
        result = model_wrapper.predict(image_bytes)
    except RuntimeError as e:
        # Model checkpoint missing/not loaded
        raise HTTPException(status_code=503, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=422, detail=f"Could not process image: {e}")

    return JSONResponse(content=result)
