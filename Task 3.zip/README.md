# Image Classifier API

A FastAPI service that wraps the ResNet18 transfer-learning image
classifier (from the companion training script) behind a REST API, and
ships as a Docker container for easy deployment.

## Project structure

```
model-api/
├── app/
│   ├── main.py        # FastAPI app + routes (/health, /predict)
│   ├── model.py        # Model loading + inference logic
│   └── schemas.py      # Request/response Pydantic models
├── model/
│   └── model.pth        # <- put your trained checkpoint here (not included)
├── sample_requests/
│   ├── curl_example.sh
│   ├── python_client_example.py
│   └── sample_car.jpg   # placeholder test image
├── Dockerfile
├── requirements.txt
├── .dockerignore
└── .gitignore
```

## 1. Get a trained model

This API expects a checkpoint produced by the training script (`torch.save`
of a dict with `model_state_dict`, `class_names`, `img_size`). Train one
with the companion `train.py`, then copy it in:

```bash
cp /path/to/your/model.pth model/model.pth
```

The API will still start without a checkpoint present — `/health` will
report `model_loaded: false` and `/predict` will return a `503` explaining
what's missing — so you can verify the service is wired up correctly
before you have a real model.

## 2. Run locally without Docker

```bash
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

Visit `http://localhost:8000/docs` for interactive Swagger UI, or use the
curl examples below.

## 3. Run with Docker

Build the image:

```bash
docker build -t image-classifier-api .
```

Run the container:

```bash
docker run -p 8000:8000 image-classifier-api
```

If you'd rather mount the model at runtime instead of baking it into the
image (useful for swapping models without rebuilding):

```bash
docker build -t image-classifier-api --build-arg SKIP_MODEL=1 .   # or just leave model/ empty
docker run -p 8000:8000 -v $(pwd)/model:/app/model image-classifier-api
```

Check it's up:

```bash
curl http://localhost:8000/health
```

## 4. Example request & response

**Request** (multipart file upload):

```bash
curl -X POST http://localhost:8000/predict \
  -F "file=@sample_requests/sample_car.jpg;type=image/jpeg"
```

**Response**:

```json
{
  "predicted_class": "automobile",
  "confidence": 0.9421,
  "probabilities": [
    { "class_name": "airplane", "probability": 0.0113 },
    { "class_name": "automobile", "probability": 0.9421 },
    { "class_name": "ship", "probability": 0.0044 },
    { "class_name": "truck", "probability": 0.0422 }
  ],
  "inference_time_ms": 18.7
}
```

**Health check**:

```bash
curl http://localhost:8000/health
```

```json
{
  "status": "ok",
  "model_loaded": true,
  "device": "cpu"
}
```

A ready-to-run script and Python client are in `sample_requests/`:

```bash
cd sample_requests
./curl_example.sh
python python_client_example.py sample_car.jpg
```

## API reference

| Method | Path       | Description                                   |
|--------|------------|------------------------------------------------|
| GET    | `/`        | Basic service info                             |
| GET    | `/health`  | Health check; reports if model is loaded       |
| POST   | `/predict` | Upload an image (`file` field), get predictions |

`/predict` accepts `image/jpeg`, `image/png`, `image/jpg`, `image/webp`.
Errors return standard HTTP status codes: `400` for a bad/unsupported
file, `422` if the image can't be processed, `503` if no model is loaded.

## Pushing this to GitHub

```bash
cd model-api
git init
git add .
git commit -m "Initial commit: FastAPI image classifier service"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```

Note: `model/*.pth` is gitignored by default since model weights are
typically large — commit it deliberately, use Git LFS, or attach it as
a GitHub Release asset and download it in your deploy step instead.

## Deploying elsewhere

The image is a standard container, so it runs anywhere that accepts
Docker images: Cloud Run, ECS/Fargate, Azure Container Apps, Render,
Fly.io, a Kubernetes Deployment, etc. Just make sure `model/model.pth`
is present in the image or mounted as a volume/secret at `/app/model/model.pth`
(or point `MODEL_PATH` at wherever you place it).
